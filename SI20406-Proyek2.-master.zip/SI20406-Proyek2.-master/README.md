# SI20406-Proyek2.
Tugas Proyek #2 untuk Memenuhi tugas proyek 2 AMD dari Kelompok E

Tema Aplikasi : Produktifitas
Nama Aplikasi : E-Notes

Kelompok E :
- Arief Kurniawan - 1941415
- Nanda Handayani - 
- Siti Aisah Jamil - 1941488 
- Rani rohaeni - 
- Huchi Wulandari - 

Aplikasi ini dibuat dengan :
- IDE : Android Studio
- Bahasa Pemrograman : Java
- Autentikasi Firebase
